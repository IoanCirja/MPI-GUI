export interface Suspension{
    id: string;
    user_id: string;
    username: string;
    email: string;
    start_date: string;
    suspend_time: number;
}